<?php
$a=23456;
while ( $a>1) {
	$reverse=$a%10;
	$a=$a/10;
	echo "$reverse";
	# code...
}


?>
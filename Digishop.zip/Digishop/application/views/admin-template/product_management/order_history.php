
        <div class="container-fluid">
          <h1 class="h3 mb-2 text-gray-800">ordes history</h1>
          <div class="card shadow mb-4">

            <div class="card-body">
              <div class="table-responsive">
                <a href="<?php echo base_url();?>index.php/admin/add_product" class="btn  btn-primary" style="float: right;">+Add</a>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>S.no</th>
                      <th>Product Name</th>
                      <th>Product Image</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Description</th>
                       <th>user_id</th>
                        <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
             <?php
            $data=(array)$result;
            foreach ($data as $key_data =>$val_data) {
              $status=$val_data->cart_status;
             ?>
             <?php
             if($status==1)
             {
              ?>
                    <tr>
                      <td><?php echo $val_data->cart_id?></td>
                      <td><?php echo $val_data->product_name?></td>
                      <td ><img src="<?php echo base_url('uploads/' . $val_data->product_file);?>" style="width: 50px; height: 50px;"></td>
                      <td><?php echo $val_data->product_quantity?></td>
                      <td><?php echo $val_data->product_price?></td>
                      <td><?php echo $val_data->product_description?></td>
                      <td><?php echo $val_data->user_id?></td>
                      <td><?php echo $val_data->cart_status?></td>
                    <td>
                       <a href=""><i class="fa fa-edit"></i></a>                      
                       <a href=""><i class="fa fa-trash" aria-hidden="true"></i></a>
                    </td>
                    </tr>
                       <?php
                     }
                   }
                     ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
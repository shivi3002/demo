
        <div class="container-fluid">
          <h1 class="h3 mb-2 text-gray-800">Products</h1>
          <div class="card shadow mb-4">

            <div class="card-body">
              <div class="table-responsive">
                <a href="<?php echo base_url();?>index.php/admin/add_product" class="btn  btn-primary" style="float: right;">+Add</a>
                <div class="input-group" style="width: 300px">
              <input type="text" class="form-control bg-light border-0 small" onkeyup="search_function()" placeholder="Search for..." aria-label="Search" name="search" id="search"  aria-describedby="basic-addon2">
             
            </div>
            <br>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>S.no</th>
                      <th>Product Name</th>
                      <th>Product Image</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Description</th>
                      <th>Product Type</th>
                      <th>Product Category</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
             <?php
             $i=1;
            $data=(array)$result;
            foreach ($data as $key_data =>$val_data) {
             ?>
                    <tr>
                      <td><?php echo $i?></td>
                      <td><?php echo $val_data->product_name?></td>
                      <td ><img src="<?php echo base_url('uploads/' . $val_data->file_name);?>" style="width: 50px; height: 50px;"></td>
                      <td><?php echo $val_data->product_quantity?></td>
                      <td><?php echo $val_data->product_price?></td>
                      <td><?php echo $val_data->product_description?></td>
                      <td><?php echo $val_data->product_type?></td>
                      <td><?php echo $val_data->product_category?></td>
                    <td>
                       <a href="<?php echo base_url();?>index.php/admin/product_edit/<?php echo $val_data->product_id;?>"><i class="fa fa-edit"></i></a>                      
                       <a href="<?php echo base_url();?>index.php/admin/product_delete/<?php echo $val_data->product_id;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                    </td>
                    </tr>
                       <?php
                     $i++;
                     }
                     ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  <script type="text/javascript">
  function search_function()
  {
    var search = $('#search').val();
    if(search)
    {
      $.ajax({
        url: '<?php echo base_url()?>index.php/admin/getsearch',
        type:'POST',
        dataType:"json",
        async: false,
        data :{'search':search},
        success:function(data){

            console.log(data);
          if(!(data.status)){
            var row = "";
            row+="<tr><th>Product name</th><th>Product image</th><th>Product Quantity</th><th>Product Description</th><th>Product type</th><th>Product Category</th></tr>";
            $(data).each(function(i, v){
              row += "<tr><td>"+ data[i].product_name +"</td><td>"+ data[i].file_name +"</td><td>"+ data[i].product_quantity +"</td><td>"+ data[i].product_description +"</td><td>"+ data[i].product_type +"</td><td>"+ data[i].product_category +"</td><tr>";
            });
            }
          $("#dataTable").html(row);
          // alert(row);
       }
      });
    }
    }

</script>


<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
      width: 800px;
    margin: auto;

}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}


/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
<div class="container">
  <a href="<?php echo base_url()?>index.php/admin/product_management" class="btn btn-primary" style="float: right;">Back</a>
  <h2>Edit Products</h2>

  <form action="<?php echo base_url();?>index.php/admin/product_update" method="post" enctype="multipart/form-data">
    <?php
  $data=(array)$result;
  foreach ($data as $key_data => $val_data)
   {
  ?>
    <div class="row">
      <div class="col-25">
        <label for="fname">Product Name</label>
      </div>
      <div class="col-75">
          <input type="text" name="product_id" value="<?php echo $val_data->product_id; ?>">
        <input type="text" name="product_name" placeholder="Product name" value="<?php echo $val_data->product_name?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Price</label>
      </div>
      <div class="col-75">
        <input type="text" name="product_price" placeholder="Product Price." value="<?php echo $val_data->product_price?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Quantity</label>
      </div>
     <div class="col-75">
        <input type="text" name="product_quantity" placeholder="Quantity" value="<?php echo $val_data->product_quantity?>">
      </div>  
         </div>
         <div class="row">
      <div class="col-25">
        <label for="lname">Product Images</label>
      </div>
      <div class="col-75">
        <input type="file"name='file_name' value="<?php echo $val_data->file_name?>">
      </div>
    </div>
      <div class="row">
      <div class="col-25">
        <label for="lname">Product Type</label>
      </div>
      <div class="col-75">  
        <select name="product_type">
          <option value="0">Featured Pr0ducts</option>
          <option value="1">Latest Products</option>
        </select>    
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Product Category</label>
      </div>
      <div class="col-75">  
        <select name="product_category" id="product_category">
          <option value="0">Electronics</option>
          <option value="1">Clothes</option>
          <option value="2">sneakers</option>
        </select>    
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Product description</label>
      </div>
      <div class="col-75">
        <textarea name="product_description" value="<?php echo $val_data->product_description?>"></textarea>
                <script>
                        CKEDITOR.replace( 'product_description' );
                </script>
      </div>
    </div>
    <div class="row">
      <input type="submit"  name="submit" value="submit">
    </div>
    <?php
    }
    ?>
  </form>
</div>



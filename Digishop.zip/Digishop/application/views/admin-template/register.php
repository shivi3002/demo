

  <div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
         <!--  <div class="col-lg-5 d-none d-lg-block bg-register-image"></div> -->
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">EDIT USER DATA</h1>
              </div>
              <form  action="<?php echo base_url();?>index.php/admin/user_update" method="post">
                <?php
                $data=(array)$result;
                foreach ($data as $key_data => $val_data) {
                ?>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                       <input type="text" class="form-control form-control-user" name="user_id" value="<?php echo $val_data->user_id?>" >
                    <input type="text" class="form-control form-control-user" name="user_name" value="<?php echo $val_data->user_name?>">
                  </div>
                 <div class="col-sm-6">
                    <input type="text" class="form-control form-control-user" name="user_email" value="<?php echo $val_data->user_email?>">
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user" name="user_address" value="<?php echo $val_data->user_address?>" placeholder="Enter address here">
                  </div>
                  <div class="col-sm-6">
                    <input type="text" class="form-control form-control-user" name="user_phone" value="<?php echo $val_data->user_phone?>" placeholder="Enter phone here" readonly="">
                  </div>
                </div>
                 <input type="submit" name="submit" class="btn btn-primary btn-user btn-block" style="width: 150px; float: right;">
  
                <?php
              }
              ?>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>



        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">User Management</h1>
          

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <!-- <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"></h6>
            </div> -->
            <div class="card-body">
              <div class="table-responsive">
                
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <!-- <?php echo $this->db->last_query();?> -->
                    <tr>
                      <th>S.no</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>phone</th>
                      <th>Address</th>
                      
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                <?php
                 $data = (array)$result;
                 $i=1;
              foreach ($data as $key_data => $val_data) {
                             ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo $val_data->user_name;?></td>
                      <td><?php echo $val_data->user_email;?></td>
                      <td><?php echo $val_data->user_phone;?></td>
                      <td><?php echo $val_data->user_address;?></td>
                     <td>
                       <a href="<?php echo base_url();?>index.php/admin/user_edit/<?php echo $val_data->user_id;?>" ><i class="fa fa-edit"></i></a>      
                       <a href="<?php echo base_url();?>index.php/admin/delete_user_list/<?php echo $val_data->user_id;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                    </tr>
                  <?php
                    $i++;
                       }
                    ?>  

                  </tbody>

                </table>
                  <div class="pagination" style="margin-left: 500px;">
                 <p><?php echo $links; ?></p> 
</div>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      
      <!-- End of Main Content

<style type="text/css">
	.submitt input{
		    width: 229px;
	}
	.submitt i{
		margin: 14px -23px;
    font-size: 17px;
	}
</style>
	<!-- Header End====================================================================== -->
	<div id="mainBody">
		<div class="container">
		<div class="row">
	<!-- Sidebar ================================================== -->
		<div id="sidebar" class="span3">
			<div class="well well-small"><a id="myCart" href="product_summary.html"><img src="themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>
			<ul id="sideManu" class="nav nav-tabs nav-stacked">
				<li class="subMenu open"><a> ELECTRONICS [230]</a>
					<ul>
					<li><a class="active" href="products.html"><i class="icon-chevron-right"></i>Cameras (100) </a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Computers, Tablets & laptop (30)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Mobile Phone (80)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Sound & Vision (15)</a></li     >
					</ul>
				</li>
				<li class="subMenu"><a> CLOTHES [840] </a>
				<ul style="display:none">
					<li><a href="products.html"><i class="icon-chevron-right"></i>Women's Clothing (45)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Women's Shoes (8)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Women's Hand Bags (5)</a></li>	
					<li><a href="products.html"><i class="icon-chevron-right"></i>Men's Clothings  (45)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Men's Shoes (6)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Kids Clothing (5)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Kids Shoes (3)</a></li>											
				</ul>
				</li>
				<li class="subMenu"><a>FOOD AND BEVERAGES [1000]</a>
					<ul style="display:none">
					<li><a href="products.html"><i class="icon-chevron-right"></i>Angoves  (35)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>Bouchard Aine & Fils (8)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>French Rabbit (5)</a></li>	
					<li><a href="products.html"><i class="icon-chevron-right"></i>Louis Bernard  (45)</a></li>
					<li><a href="products.html"><i class="icon-chevron-right"></i>BIB Wine (Bag in Box) (8)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Other Liquors & Wine (5)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Garden (3)</a></li>												
					<li><a href="products.html"><i class="icon-chevron-right"></i>Khao Shong (11)</a></li>												
				</ul>
				</li>
				<li><a href="products.html">HEALTH & BEAUTY [18]</a></li>
				<li><a href="products.html">SPORTS & LEISURE [58]</a></li>
				<li><a href="products.html">BOOKS & ENTERTAINMENTS [14]</a></li>
			</ul>
			<br/>
			  <div class="thumbnail">
				<img src="themes/images/products/panasonic.jpg" alt="Bootshop panasonoc New camera"/>
				<div class="caption">
				  <h5>Panasonic</h5>
					<h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
				</div>
			  </div><br/>
				<div class="thumbnail">
					<img src="themes/images/products/kindle.png" title="Bootshop New Kindel" alt="Bootshop Kindel">
					<div class="caption">
					  <h5>Kindle</h5>
					    <h4 style="text-align:center"><a class="btn" href="product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
					</div>
				  </div><br/>
				<div class="thumbnail">
					<img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
					<div class="caption">
					  <h5>Payment Methods</h5>
					</div>
				  </div>
		</div>
	<!-- Sidebar end=============================================== -->
		<div class="span9">
	    <ul class="breadcrumb">
			<li><a href="index.html">Home</a> <span class="divider">/</span></li>
			<li class="active"> SHOPPING CART</li>
	    </ul>
		<h3>SHOPPING CART<a href="<?php echo base_url();?>index.php/user/user_home" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>	
		<hr class="soft"/>	
		<table class="table table-bordered">
	              <thead>
	                <tr>
	                  <th>Product Image</th>
	                  <th>Product Name</th>
	                  <th>Quantity</th>
					  <th>₹	Price</th>	
	                  <th>Price after Discount 40%</th>
	                  <th>price after Tax 10%</th>
	                  <th>Total</th>
					</tr>
	              </thead>
	              <?php 
	              $totalpay=0;
	              	$data=(array)$result;
	              	foreach ($data as $key_data => $val_data) {
	              		$exp_price=$val_data->cart_status;
	              		$status=$val_data->cart_status;
	              		$product_cost=$val_data->product_price*$val_data->product_quantity;	 
	              		$discount=$product_cost*40/100;
	              		$total_after_discount=$product_cost-$discount;
	              		$tax_amount=$total_after_discount*10/100;
	              		$total_after_tax=$total_after_discount+$tax_amount;
	              		$final_amount=$total_after_tax;
	              		$totalpay=$totalpay+$final_amount;
	              	?>
	              <tbody>
	              	<form action="<?php echo base_url();?>index.php/user/update_cart_data" method="Post"> 
	                <tr>

	                  <td> <img width="60" src="<?php echo base_url('uploads/' . $val_data->product_file);?>" alt=""/></td>
	                  <td><?php echo $val_data->product_name?><br/>Color : <strong><?php echo $val_data->product_color?></strong></td>
					  <td>
						<div class="input-append"><input class="span1" style="max-width:34px" value="<?php echo $val_data->product_quantity?>" id="appendedInputButtons" size="16" type="text" readonly><button  class="btn" type="button"><a href="<?php echo base_url();?>index.php/user/delete_cart_data/<?php echo $val_data->cart_id;?>"><i class="icon-minus"></i></a></button></div>
					  </td>
					  <td><?php echo $product_cost?></td>
	                  <td><?php echo $total_after_discount?></td>
	                  <td><?php echo $total_after_tax?></td>
	                  <td><?php echo $final_amount?></td>
	                </tr>
	               <input type="hidden" name="cart_id" value="<?php echo $val_data->cart_id; ?>">
	               <input type="hidden" name="cart_status" value="1">
					</tbody>
					<?php
					 }
					?>
					<tr>
	                  <td colspan="6" style="text-align:right"><strong>TOTAL=</strong></td>
	                  <td class="label label-important" style="display:block"><strong><?php echo $totalpay?> </strong></td>
	                </tr>    
	            </table>
           <div class="submitt">
			<input type="submit" class="btn btn-large pull-left" value="Proceed To Checkout">	
			<i class="icon-arrow-right"></i>
		</div>
		</form>
	</div>
	</div></div>
	</div>

		
﻿
<div id="mainBody">
	<div class="container">
	<div class="row">

<!-- Sidebar end=============================================== -->
	<div class="span9">
   
	<h3> Registration</h3>	
	<div class="well">
	 
	<form class="form-horizontal"  action="<?php echo base_url();?>index.php/user/signup" method="post" enctype="multipart/form-data">
		
		
		<div class="control-group">
			<label class="control-label" for="inputFname1">name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="user_name" placeholder="Please Enter name">
			</div>
		 </div>
		 
		<div class="control-group">
		<label class="control-label" for="input_email">Email <sup>*</sup></label>
		<div class="controls">
		  <input type="text" id="input_email" name="user_email" placeholder="Please Enter Email">
		</div>
	  </div>	  
	<div class="control-group">
		<label class="control-label" for="inputPassword1">Password <sup>*</sup></label>
		<div class="controls">
		  <input type="password" id="inputPassword1" name="user_password" placeholder="Please Enter password">
		</div>
	  </div>	  
		<div class="control-group">
			<label class="control-label" for="address">Address<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address" name="user_address" placeholder="Please Enter Address"/> 
			</div>
		</div>
		
		<div class="control-group">
		<label class="control-label" for="phone"> Mobile no<sup>*</sup></label>
		<div class="controls">
		  <input type="text" id="phone" name="user_phone" placeholder="Please Enter phone">
		</div>
	  </div>
	<div class="control-group">
			<div class="controls">
				
				<input class="btn btn-large btn-success" type="submit" value="Register" />
			</div>
		</div>		
	</form>
</div>

</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->

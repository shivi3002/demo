<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
	
	public function insert($data)
    {
        return $this->db->insert('tbl_user',$data);
    }
    public function login_validation($user_email,$user_password)
    {
      	$this->db->where('user_email',$user_email);
        $this->db->where('user_password',$user_password);
        $result = $this->db->get('tbl_user');
        return $result;
    }

    public function get_product_data()
    {
        $this->db->select('*');
        $this->db->from('product_detail');
        $query=$this->db->get();
        return $query->result();
    }
     public function get_product_details($data)
    {
        $this->db->select('*');
        $this->db->where('product_id',$data);
        $query=$this->db->get('product_detail')->result();
        return $query;
    }
    public function add_to_cart($data)
    {
        $this->db->insert('tbl_cart',$data);
    }
    public function get_cart_data()
    {
        $user_id = $this->session->userdata('user_id');
        $this->db->select('*');
        $this->db->where('user_id',$user_id);
        $this->db->where('cart_status',0);
        $this->db->from('tbl_cart');
        $query=$this->db->get();
        return $query->result();
    }


    public function update_cart_data($data)
    {
        $user_id = $this->session->userdata('user_id');
        $this->db->where('user_id',$user_id);
        $this->db->update('tbl_cart', $data);
         $from = "shivamgpta98@gmail.com";    //senders email address
          $subject = 'Verify email address';
          $receiver = $this->session->userdata('user_email');
          //email subject
          //sending confirmEmail($receiver) function calling link to the user, inside message body
          $message = 'Dear'.$this->session->userdata('user_name').'<br><br> Your order is succesfully ordered<br><br>';
          $config['protocol'] = 'smtp';
          $config['smtp_host'] = 'ssl://smtp.gmail.com';
          $config['smtp_port'] = '465';
          $config['smtp_user'] = $from;
          $config['smtp_pass'] = 'shivi3002';  //sender's password
          $config['mailtype'] = 'html';
          $config['charset'] = 'iso-8859-1';
          $config['wordwrap'] = 'TRUE';
          $config['newline'] = "\r\n"; 
          
          $this->load->library('email', $config);
          $this->email->initialize($config);
          //send email
          $this->email->from($from);
          $this->email->to($receiver);
          $this->email->subject($subject);
          $this->email->message($message);
          
          if($this->email->send())
            {
                echo "sent";
            }
            else
            {
                echo "failed";
            }
    }

        public function delete_cart_data($cart_id)
        {
            $this->db->where( 'cart_id', $cart_id);
            $this->db->delete('tbl_cart');
        }
}
?>
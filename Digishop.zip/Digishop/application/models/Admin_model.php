<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function record_count() {
    return $this->db->count_all("tbl_user");
    }
	public function get_user_data($limit, $start)
	{
		$this->db->select('*');
        $this->db->limit($limit, $start);
		$this->db->from('tbl_user');
		$query=$this->db->get();
		return $query->result();
	} 
	public function delete($user_id){          
    $this->db->where('user_id', $user_id);
    $this->db->delete('tbl_user');   
    }
    public function user_edit($data)
        {                           
            $this->db->select('*');
            $this->db->where('user_id',$data);
            $query=$this->db->get('tbl_user')->result();
            return $query;
        }
    public function user_update($user_id,$data)
        {
            $this->db->where('user_id',$user_id);
            $this->db->update('tbl_user', $data);
        }
    public function insert_product_data($data)
    {
            $this->db->insert('product_detail ',$data);
    }
    public function get_product()
    {
        $this->db->select('*');
        $this->db->from('product_detail');
        $query=$this->db->get();
        return $query->result();
    }
    public function delete_product($product_id)
    {
        $this->db->where('product_id', $product_id);
        $this->db->delete('product_detail');
    }
    public function product_edit($data)
    {
        $this->db->select('*');
        $this->db->where('product_id',$data);
        $query=$this->db->get('product_detail')->result();
        return $query;
    }
    public function product_update($product_id,$data)
    {
        $this->db->where('product_id',$product_id);
        $this->db->update('product_detail', $data);
    }
    public function  get_order()
    {
        $this->db->select('*');
        $this->db->from('tbl_cart');
        $query=$this->db->get();
        return $query->result();
    }
       public function  get_order_history()
    {
        $this->db->select('*');
        $this->db->from('tbl_cart');
        $query=$this->db->get();
        return $query->result();
    }
 public function search_order($search){
      $this->db->select("*");
      $this->db->from("product_detail");
    if($search !='')
    {
   $this->db->like('product_name', $search);
   $this->db->or_like('file_name', $search);
   $this->db->or_like('product_quantity', $search);
   $this->db->or_like('product_description', $search);
   $this->db->or_like('product_type', $search);
   $this->db->or_like('product_category', $search);
   $this->db->or_like('file_name', $search);
    }
    $this->db->order_by('product_id', 'DESC');
      $result = $this->db->get()->result();
      return $result;
     }

}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	public function __construct(){
	        parent::__construct();
	        $this->load->library('session');
	        $this->load->library('email');
	        $this->load->helper('url');
	        $this->load->database();
	        $this->load->model('User_model');
	}   
	public function index()
	{   
		$data['result']=$this->User_model->get_product_data();
		$this->load->view('templates/header1');
		$this->load->view('User/index',$data);
	    $this->load->view('templates/footer1');
	}

// for user registration
	public function register()
	{    	
        $this->load->view('templates/header1');
		$this->load->view('User/register');
        $this->load->view('templates/footer1');
	}
	public function signup(){
	    $data = array(
		'user_name'    => $this->input->post('user_name'),
	    'user_email'   => $this->input->post('user_email'),
        'user_address' => $this->input->post('user_address'),
	    'user_phone'   => $this->input->post('user_phone'),
	    'user_password'=> $this->input->post('user_password')
		          );
		         $this->User_model->insert($data);
                 redirect(base_url() . 'index.php/User/index');
    }   
    
// 	// for login user
	public function user_login(){
			    $user_email    = $this->input->post('user_email',TRUE);
			    $user_password = $this->input->post('user_password',TRUE);   
			    $validate = $this->User_model->login_validation($user_email,$user_password);
	          
	    	if($validate->num_rows() > 0){
		        $data  = $validate->row_array();
		        $user_id  = $data['user_id'];
		        $user_name  = $data['user_name'];
	            $user_address = $data['user_address'];
		        $user_email = $data['user_email'];
		        $user_password = $data['user_password'];
		        $sesdata = array(
		            'user_name'  => $user_name,
		            'user_email'  => $user_email,
		            'user_id' => $user_id,
	            	'logged_in'=> TRUE
		        );

	        	$this->session->set_userdata($sesdata)
	        	;
	        	// echo "welcome to mini shop";
	        redirect(base_url() . 'index.php/User/user_home');
	   		}
	    else{
	        // echo "login failed";
	        // echo $this->session->set_flashdata('msg','Username or Password is Wrong');
	        redirect(base_url() . 'index.php/User/index');
	        }
	      
	}
	public function logout()
	{
	      $this->session->unset_userdata('user_email');
	      redirect(base_url() . 'index.php/User/index');
	}
	public function user_home()
	{ 
	 	if($this->session->userdata('user_email') != '')
	    {
	    	$data['result']=$this->User_model->get_product_data();
	    	 // echo json_encode($data);
	      	$this->load->view('templates/header2');
			$this->load->view('User/index',$data);
		    $this->load->view('templates/footer1');
	    }
	}
	public function product_details($product_id)
	{	
	 	if($this->session->userdata('user_email') != '')
	    {
	 		$product_id=$this->uri->segment(3);
	 		$data['result']=$this->User_model->get_product_details($product_id);
			$this->load->view('templates/header2');
			$this->load->view('User/product_details',$data);
		    $this->load->view('templates/footer1');
		}
	}
	public function add_to_cart()
	{		
	 	if($this->session->userdata('user_email') != '')
	    {
				$data = array('product_file'=>$this->input->post('file_name'),
			                  'product_name' =>$this->input->post('product_name'),
			                  'product_price' =>$this->input->post('product_price'),
			                  'product_quantity' =>$this->input->post('product_quantity'),
			                  'product_description' =>$this->input->post('product_description'),
			                  'product_color' =>$this->input->post('product_color'),
			                  'user_id' => $this->input->post('user_id'),
			                  'cart_status' => $this->input->post('cart_status') 
			                   );
			            $this->User_model->add_to_cart($data);
			            redirect(base_url() . 'index.php/User/add_to_cart_view');
		}
	}
	public function add_to_cart_view()
	{
			if($this->session->userdata('user_email')!='')
	        {
				$data['result']=$this->User_model->get_cart_data();
			 	$this->load->view('templates/header2');
				$this->load->view('User/product_cart',$data);
				$this->load->view('templates/footer1');
			}
	}  
	// status if 1 proceed to chckout
	public function update_cart_data()
	{	
	    if($this->session->userdata('user_email')!='')
	        {
	            $data=array(
	                        'cart_status'=>$this->input->post('cart_status')
	                    ); 
	             $this->User_model->update_cart_data($data);
	        }
	     }
	// for delete data
	public function delete_cart_data()
	{
		 	$cart_id = $this->uri->segment(3);
		  	$this->User_model->delete_cart_data($cart_id);
            redirect(base_url().'index.php/user/add_to_cart_view'); 
	}
	

}  
?>
 
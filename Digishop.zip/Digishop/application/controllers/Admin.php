<?php
class Admin extends CI_Controller
{
public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->library('email');
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('admin_model');
        $this->load->library('pagination');
    }
 public function index()
{
 $this->load->view('admin-template/admin_login');
}
public function admin_login()  
    {  
        $email = $this->input->post('email');  
        $password = $this->input->post('password');  
        if ($email=='shivamgpta97@gmail.com' && $password=='12345')   
        {  

        	$session_data = array(
        		'email' => $email,
        	);

  	$this->session->set_userdata($session_data);
  	   // echo"welcome admin ";
            redirect(base_url('index.php/admin/admin_dashboard'));

        }  
        else{  
            $data['error'] = 'Email/password is Invalid';  
             $this->load->view('admin-template/admin_login', $data);  
        }  
    }
    public function admin_dashboard()
    {
    	if($this->session->userdata('email') != '')
    	{
    		$this->load->view("admin-template/templates/adminheader");
	    	$this->load->view('admin-template/admin_dashboard');
	    	$this->load->view("admin-template/templates/adminfooter");
    	}
    }
    public function user_mgmt()
    {
    	if($this->session->userdata('email') != '')
    	{
    		$this->load->view("admin-template/templates/adminheader");
	    	$this->load->view('admin-template/table');
	    	$this->load->view("admin-template/templates/adminfooter");
    	}
    }
    public function user_list()
    {
    	if($this->session->userdata('email') != '')
    	{
           $config = array();
           $config["base_url"] =  base_url('index.php/admin/user_list');
           $config["total_rows"] = $this->admin_model->record_count();
           $config["per_page"] = 1;
           $config["uri_segment"] = 3;
           $this->pagination->initialize($config);
           $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
           $data['result'] = $this->admin_model->get_user_data($config["per_page"], $page);
           $data["links"] = $this->pagination->create_links();
        	$this->load->view("admin-template/templates/adminheader");
        	$this->load->view('admin-template/table',$data);
        	$this->load->view("admin-template/templates/adminfooter");
    	}		
    }
    public function delete_user_list()
    { 
    	if($this->session->userdata('email') != '')
    	{
	    	$user_id = $this->uri->segment(3);
	    	$this->admin_model->delete($user_id);
	    	redirect(base_url() . 'index.php/admin/user_list');
	    }
    }
    public function user_edit($user_id)
    {
        $user_id  = $this->uri->segment(3);
        $data['result'] = $this->admin_model->user_edit($user_id);
        $this->load->view("admin-template/templates/adminheader");
        $this->load->view('admin-template/register',$data);
        $this->load->view("admin-template/templates/adminfooter");             
    } 
     public function user_update()
    {
        if($this->session->userdata('email')!='')
        {
            $user_id=$this->input->post('user_id');
            $data=array(
                        'user_name'=>$this->input->post('user_name'),
                        'user_email'=> $this->input->post('user_email'),
                        'user_phone'=>$this->input->post('user_phone'),
                        'user_address'=>$this->input->post('user_address')
                    ); 
            $this->admin_model->user_update($user_id,$data);
        }
    }
    public function product_management()    
    {
    	// if($this->session->userdata('email') != '')
    	// // {
            $data['result']=$this->admin_model->get_product();
            
			$this->load->view("admin-template/templates/adminheader");
		    $this->load->view('admin-template/product_management/product_tbl', $data);
		    $this->load->view("admin-template/templates/adminfooter");
		// }
	}
    public function add_product()
    {
    	if($this->session->userdata('email') != '')
    	{
			$this->load->view("admin-template/templates/adminheader");
		    $this->load->view('admin-template/product_management/product_add');
		    $this->load->view("admin-template/templates/adminfooter");
		}
    }
    public function add_product_data()
    { 
        if($this->session->userdata('email') != '')
        {
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = '|jpg|png|';
            $this->load->library('upload', $config);
            $this->upload->do_upload('file_name');
            $up_file_name = $this->upload->data();
            $data = array('file_name' => $up_file_name['file_name'],
                          'product_name' =>$this->input->post('product_name'),
                          'product_price' =>$this->input->post('product_price'),
                          'product_quantity' =>$this->input->post('product_quantity'),
                          'product_description' =>$this->input->post('product_description'),
                          'product_type' => $this->input->post('product_type'),
                          'product_category'=>$this->input->post('product_category')   
                        );
            $this->admin_model->insert_product_data($data);
            redirect(base_url().'index.php/admin/product_management'); 
        }
    } 
    public function product_delete()
    {
        if($this->session->userdata('email')!='')
        {
            $product_id = $this->uri->segment(3);
            $this->admin_model->delete_product($product_id);
            redirect(base_url().'index.php/admin/product_management');    
        }
    }  
    public function product_edit($product_id)
    {
        if($this->session->userdata('email')!='')
        {
            $product_id  = $this->uri->segment(3);
            $data['result'] = $this->admin_model->product_edit($product_id);
            $this->load->view("admin-template/templates/adminheader");
            $this->load->view('admin-template/product_management/product_add_edit',$data);
            $this->load->view("admin-template/templates/adminfooter");
        }            
    } 
    public function product_update()
    {
        if($this->session->userdata('email')!='')
        {
            $product_id=$this->input->post('product_id');
            $data=array(
                        'product_name'=>$this->input->post('product_name'),
                        'product_price'=> $this->input->post('product_price'),
                        'product_quantity'=>$this->input->post('product_quantity'),
                        'product_type'=>$this->input->post('product_type'),
                        'product_category'=>$this->input->post('product_category'),
                        'product_description'=>$this->input->post('product_description')
                    ); 
            $this->admin_model->product_update($product_id,$data);
            redirect(base_url().'index.php/admin/product_management'); 
        }
    }
    public function logout()
    {
        $this->session->unset_userdata('email');
        redirect(base_url() . 'index.php/admin/index');
    }
    public function order_data()
    {
        if($this->session->userdata('email') != '')
        {
            $data['result']=$this->admin_model->get_order();
            $this->load->view("admin-template/templates/adminheader");
            $this->load->view('admin-template/product_management/order_data', $data);
            $this->load->view("admin-template/templates/adminfooter");
        }
    }
     public function order_history()
    {
        if($this->session->userdata('email') != '')
        {
            $data['result']=$this->admin_model->get_order_history();
            $this->load->view("admin-template/templates/adminheader");
            $this->load->view('admin-template/product_management/order_history', $data);
            $this->load->view("admin-template/templates/adminfooter");
        }
    }
    public function getsearch(){
    if($this->session->userdata('email') != '')
        {
        $search = $this->input->post('search');
        $query = $this->admin_model->search_order($search);
        echo json_encode ($query);
        }
    }


}

?>
